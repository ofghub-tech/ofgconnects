import { Client, Databases } from 'node-appwrite';
import { pipeline } from '@xenova/transformers';

// Create a "singleton" to load the model only once
class EmbeddingPipeline {
  static task = 'feature-extraction';
  static model = 'Xenova/all-MiniLM-L6-v2'; // A fast, high-quality model
  static instance = null;

  static async getInstance() {
    if (this.instance === null) {
      this.instance = pipeline(this.task, this.model);
    }
    return this.instance;
  }
}

export default async ({ req, res, log, error }) => {
  // Get variables from function settings
  const { 
    APPWRITE_API_KEY, 
    APPWRITE_DATABASE_ID, 
    APPWRITE_COLLECTION_ID_VIDEOS 
  } = process.env;

  const client = new Client()
    .setEndpoint(process.env.APPWRITE_ENDPOINT)
    .setProject(process.env.APPWRITE_PROJECT_ID)
    .setKey(APPWRITE_API_KEY);

  const databases = new Databases(client);

  try {
    const video = JSON.parse(req.body);
    log(`Processing video: ${video.$id}`);

    const textToEmbed = video.title + ". " + video.description;
    if (!video.title && !video.description) {
      log("No title or description, skipping.");
      return res.json({ success: true, message: "No text" });
    }

    const embedder = await EmbeddingPipeline.getInstance();

    const output = await embedder(textToEmbed, {
      pooling: 'mean',
      normalize: true,
    });
    const embedding = Array.from(output.data); 

    await databases.updateDocument(
      APPWRITE_DATABASE_ID,
      APPWRITE_COLLECTION_ID_VIDEOS,
      video.$id,
      {
        'vector_embedding': embedding, // The Attribute ID from Phase 1
      }
    );

    log(`Successfully generated and saved embedding for ${video.$id}.`);
    return res.json({ success: true });

  } catch (e) {
    error(e);
    return res.json({ success: false, error: e.message }, 500);
  }
};